<?php

error_reporting(~E_NOTICE);
$controller = isset($_GET['c']) ? $_GET['c'] : 'Home';
$method = isset($_GET['m']) ? $_GET['m'] : 'index';

include_once "controller/controllerclass.php";
include_once "controller/$controller.php";

(new $controller)->$method();