<?php
class PostModel extends Model {
    // ...

    public function delete($id) {
        $sql = "DELETE FROM post WHERE id = ?";

        // Prepare the statement
        $stmt = $this->mysqli->prepare($sql);

        // Bind the parameter
        $stmt->bind_param("i", $id);

        // Execute the query
        $stmt->execute();

        // Close the statement
        $stmt->close();
    }
}