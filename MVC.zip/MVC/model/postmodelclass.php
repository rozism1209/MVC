<?php
class PostModel extends Model {

public function getById($id) {
    $sql = "SELECT * FROM post WHERE id = $id";
    return $this->mysqli->query($sql);
}

public function insert($title, $content) {
    $sql = "INSERT INTO post (title, content) VALUES ('$title', '$content')";
    $this->mysqli->query($sql);
}
}