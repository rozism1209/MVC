<?php
class Post extends Controller {
    // ...

    public function edit_process() {
        $postModel = $this->loadModel('PostModel');
        $id = $_POST['id'];
        $title = $_POST['title'];
        $content = $_POST['content'];

        // Use prepared statements to prevent SQL injection
        $postModel->update($id, $title, $content);

        header('Location: ?c=Post');
    }
}