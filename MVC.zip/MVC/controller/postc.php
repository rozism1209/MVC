<?php
class Post extends Controller {
    // ...

    public function delete() {
        // Validate the incoming ID
        if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
            // Handle invalid ID, e.g., redirect to error page or display an error message
            header('Location: ?c=Post&error=invalid_id');
            exit();
        }

        $id = intval($_POST['id']); // Sanitize the ID to prevent SQL injection

        $postModel = $this->loadModel('PostModel');

        // Use prepared statements or parameterized queries to prevent SQL injection
        $postModel->delete($id);

        header('Location: ?c=Post');
    }
}