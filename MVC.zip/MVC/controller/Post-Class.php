<?php
class Post extends Controller {

    // ...

    public function edit() {
        $id = $_GET['id'];

        if (!$id) {
            header('Location: index.php?c=Post');
        }

        $postModel = $this->loadModel('PostModel');
        $post = $postModel->getById($id);

        if (!$post->num_rows) {
            header('Location: index.php?c=Post');
        }

        $this->loadView('edit', ['post' => $post->fetch_object()]);
    }
}