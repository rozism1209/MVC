<?php
class Post extends Controller {

    // ...

    public function create_form() {
        $this->loadView('insert_post');
    }

    public function create_process() {
        $postModel = $this->loadModel('PostModel');
        $title = $_POST['title'];
        $content = $_POST['content'];

        $postModel->insert($title, $content);
        header('Location: ?c=Post');
    }
}
